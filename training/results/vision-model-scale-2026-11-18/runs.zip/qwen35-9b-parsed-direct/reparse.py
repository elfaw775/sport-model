"""Re-score unambiguous Qwen bbox_2d dictionaries; pass original predictions and runtime, then an output folder."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys

sys.path.insert(0,str(Path.cwd()/'training/scripts'))
from evaluate_qwen_vl import parse_answer
from score_qwen_vl import load_qwen,score,truth


def flatten_boxes(raw):
    text = raw.strip()
    fenced = re.fullmatch(r"```(?:json)?\s*(.*?)\s*```", text, re.I | re.S)
    if fenced:
        text = fenced[1]
    try:
        obj = json.loads(text)
    except ValueError:
        return None
    if not isinstance(obj, dict) or not isinstance(obj.get("boxes"), list):
        return None
    boxes = obj["boxes"]
    if not boxes or not all(isinstance(box, dict) and "bbox_2d" in box
                            and set(box) <= {"bbox_2d", "label"} for box in boxes):
        return None
    converted = dict(obj, boxes=[box["bbox_2d"] for box in boxes])
    result = parse_answer(json.dumps(converted))
    return result if result["status"] != "parse_error" else None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("predictions",type=Path)
    parser.add_argument("runtime",type=Path)
    parser.add_argument("output",type=Path)
    args=parser.parse_args()
    args.output.mkdir(exist_ok=True)
    counts=Counter()
    rows=list(map(json.loads,args.predictions.read_text().splitlines()))
    for row in rows:
        if row["status"] == "parse_error":
            converted = flatten_boxes(row["raw"])
            if converted:
                row.pop("error",None)
                row.update(converted)
                counts[row["split"]] += 1
    p=args.output/"predictions.jsonl"
    p.write_text("".join(json.dumps(r,ensure_ascii=False)+"\n" for r in rows),encoding="utf8")
    settings=json.loads(args.runtime.read_text())
    settings.update(method="post hoc schema check; unwrap bbox_2d only, with optional label, without changing any coordinate",
                    converted_by_split=dict(counts),
                    source_predictions_sha256=hashlib.sha256(args.predictions.read_bytes()).hexdigest())
    (args.output/"runtime.json").write_text(json.dumps(settings,indent=2)+"\n")
    clean=load_qwen(p)
    metrics={s:score(truth(s),clean[s]) for s in ("val","test")}
    (args.output/"metrics.json").write_text(json.dumps(metrics,indent=2)+"\n")


if __name__=="__main__":
    main()
