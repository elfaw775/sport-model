"""Run from the repository root with the original DeepSeek direct predictions JSONL as argument."""
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path.cwd()/'training/scripts'))
from compare_detectors import iou, truth
from score_qwen_vl import AXES, load_qwen, score

path = Path(sys.argv[1])
predictions = load_qwen(path)
raw = {row['filename']: row for row in map(json.loads, path.read_text().splitlines())}
result = {
    'analysis': 'post hoc coordinate-unit sensitivity; not scored as a new model run',
    'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    'transform': 'reinterpret all raw box coordinates as fractions in [0,1] by multiplying by 1000 before the frozen 0-to-1000 scoring protocol',
    'reference_iou_threshold': 0.5,
}
for split in ('val','test'):
    labels = truth(split)
    rows = predictions[split]
    scaled = {}
    details = {}
    for name, (status, boxes) in rows.items():
        assert all(all(0 <= v <= 1 for v in box) for box in raw[name]['boxes'])
        scaled[name] = (status,[dict(b, **{axis:b[axis]*1000 for axis in AXES}) for b in boxes])
        best = []
        for target in labels[name]:
            best.append(max((iou(tuple(b[k] for k in AXES), target) for b in scaled[name][1]), default=0))
        details[name] = {'original_fractional_xyxy':raw[name]['boxes'],'reference_lesions':len(labels[name]),
                         'best_rescaled_iou_per_reference_lesion':best}
    result[split] = {'films':len(rows),'metrics_after_rescaling':score(labels,scaled)['lesion_level_iou50'],
                     'maximum_iou_after_rescaling':max(v for r in details.values() for v in r['best_rescaled_iou_per_reference_lesion']),
                     'per_film':details}
result['total_input_boxes'] = sum(len(item['boxes']) for item in raw.values())
print(json.dumps(result,ensure_ascii=False,indent=2))
